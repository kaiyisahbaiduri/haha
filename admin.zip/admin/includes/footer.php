<div class="footer-wrap pd-20 mb-20 card-box">
Copyright © 2023 Faculty of Computing and Meta-Technology
			</div>